// API Base URL
const API_BASE = '/api';

// State
let tasks = [];
let labels = [];
let draggedTask = null;
let currentTaskId = null;
let confirmCallback = null;
let alertCallback = null;
let preferences = {
    hideCompleted: false,
    confirmDelete: true,
    autoRefresh: 0
};
let autoRefreshInterval = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadPreferences();
    loadTasks();
    loadLabels();
    setupEventListeners();
    setupAutoRefresh();
});

// Event Listeners
function setupEventListeners() {
    // Toolbar buttons
    document.getElementById('refreshBtn').addEventListener('click', loadTasks);

    // New Task Button
    document.getElementById('newTaskBtn').addEventListener('click', showNewTaskDialog);

    // New Task dialog buttons
    document.getElementById('createTaskBtn').addEventListener('click', createTask);
    document.getElementById('cancelTaskBtn').addEventListener('click', hideNewTaskDialog);
    document.getElementById('closeNewDialog').addEventListener('click', hideNewTaskDialog);

    // Details dialog buttons
    document.getElementById('saveDetailsBtn').addEventListener('click', saveTaskDetails);
    document.getElementById('closeDetailsBtn').addEventListener('click', hideDetailsDialog);
    document.getElementById('closeDetailsDialog').addEventListener('click', hideDetailsDialog);
    document.getElementById('addCommentBtn').addEventListener('click', addComment);
    document.getElementById('deleteTaskBtn').addEventListener('click', handleDeleteTask);

    // Tab buttons
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });

    // Label select dropdowns
    document.getElementById('taskLabelSelect').addEventListener('change', (e) => {
        const newLabelFields = document.getElementById('taskNewLabelFields');
        if (e.target.value === '__new__') {
            newLabelFields.style.display = 'block';
        } else {
            newLabelFields.style.display = 'none';
        }
    });

    document.getElementById('detailLabelSelect').addEventListener('change', (e) => {
        const newLabelFields = document.getElementById('detailNewLabelFields');
        if (e.target.value === '__new__') {
            newLabelFields.style.display = 'block';
        } else {
            newLabelFields.style.display = 'none';
        }
    });

    // Add step button
    document.getElementById('addStepBtn').addEventListener('click', addStep);

    // Confirm dialog buttons
    document.getElementById('confirmYesBtn').addEventListener('click', () => {
        hideConfirmDialog();
        if (confirmCallback) {
            confirmCallback(true);
            confirmCallback = null;
        }
    });

    document.getElementById('confirmNoBtn').addEventListener('click', () => {
        hideConfirmDialog();
        if (confirmCallback) {
            confirmCallback(false);
            confirmCallback = null;
        }
    });

    document.getElementById('closeConfirmDialog').addEventListener('click', () => {
        hideConfirmDialog();
        if (confirmCallback) {
            confirmCallback(false);
            confirmCallback = null;
        }
    });

    // Alert dialog buttons
    document.getElementById('alertOkBtn').addEventListener('click', () => {
        hideAlertDialog();
        if (alertCallback) {
            alertCallback();
            alertCallback = null;
        }
    });

    document.getElementById('closeAlertDialog').addEventListener('click', () => {
        hideAlertDialog();
        if (alertCallback) {
            alertCallback();
            alertCallback = null;
        }
    });

    // Click outside to close dialogs
    document.getElementById('dialogOverlay').addEventListener('click', () => {
        hideNewTaskDialog();
        hideDetailsDialog();
        hideConfirmDialog();
        hideAlertDialog();
        hidePreferencesDialog();
    });

    // Preferences dialog
    document.getElementById('savePreferencesBtn').addEventListener('click', savePreferences);
    document.getElementById('cancelPreferencesBtn').addEventListener('click', hidePreferencesDialog);
    document.getElementById('closePreferencesDialog').addEventListener('click', hidePreferencesDialog);
    document.getElementById('clearCompletedBtn').addEventListener('click', clearCompletedTasks);

    // Menu bar
    setupMenuBar();

    // Drag and drop for columns
    const columns = document.querySelectorAll('.column-body');
    columns.forEach(column => {
        column.addEventListener('dragover', handleDragOver);
        column.addEventListener('drop', handleDrop);
        column.addEventListener('dragleave', handleDragLeave);
    });
}

// Menu Bar
function setupMenuBar() {
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(item => {
        item.addEventListener('click', (e) => {
            const menuText = e.target.textContent;
            showMenuDropdown(e.target, menuText);
        });
    });
}

function showMenuDropdown(menuItem, menuText) {
    // Remove existing dropdowns
    document.querySelectorAll('.menu-dropdown').forEach(d => d.remove());

    const dropdown = document.createElement('div');
    dropdown.className = 'menu-dropdown';

    const rect = menuItem.getBoundingClientRect();
    dropdown.style.position = 'absolute';
    dropdown.style.left = `${rect.left}px`;
    dropdown.style.top = `${rect.bottom}px`;

    let items = [];
    switch(menuText) {
        case 'File':
            items = [
                { text: 'New Task', action: showNewTaskDialog },
                { separator: true },
                { text: 'Refresh', action: loadTasks },
                { separator: true },
                { text: 'Exit', action: () => showAlert('Thanks for using Task Manager!') }
            ];
            break;
        case 'Edit':
            items = [
                { text: 'Select All', action: () => showAlert('Select All not yet implemented') },
                { separator: true },
                { text: 'Preferences', action: showPreferencesDialog }
            ];
            break;
        case 'View':
            items = [
                { text: 'Refresh', action: loadTasks },
                { separator: true },
                { text: 'Status Bar', action: () => showAlert('Status bar is always visible') }
            ];
            break;
        case 'Help':
            items = [
                { text: 'Help Topics', action: () => showAlert('Drag cards between columns to update status!\nClick cards to view details.') },
                { separator: true },
                { text: 'About', action: () => showAlert('Task Manager - Windows 98 Edition\nVersion 1.0\nBuilt for Executive Dysfunction') }
            ];
            break;
    }

    items.forEach(item => {
        if (item.separator) {
            const sep = document.createElement('div');
            sep.className = 'menu-dropdown-separator';
            dropdown.appendChild(sep);
        } else {
            const menuItem = document.createElement('div');
            menuItem.className = 'menu-dropdown-item';
            menuItem.textContent = item.text;
            menuItem.addEventListener('click', () => {
                item.action();
                dropdown.remove();
            });
            dropdown.appendChild(menuItem);
        }
    });

    document.body.appendChild(dropdown);

    // Close on click outside
    setTimeout(() => {
        document.addEventListener('click', function closeDropdown(e) {
            if (!dropdown.contains(e.target)) {
                dropdown.remove();
                document.removeEventListener('click', closeDropdown);
            }
        });
    }, 0);
}

// API Calls
async function loadTasks() {
    try {
        const response = await fetch(`${API_BASE}/tasks`);
        tasks = await response.json();
        renderTasks();
    } catch (error) {
        console.error('Failed to load tasks:', error);
    }
}

async function loadLabels() {
    try {
        const response = await fetch(`${API_BASE}/labels`);
        labels = await response.json();
        populateLabelSelects();
    } catch (error) {
        console.error('Failed to load labels:', error);
    }
}

function populateLabelSelects() {
    const taskSelect = document.getElementById('taskLabelSelect');
    const detailSelect = document.getElementById('detailLabelSelect');

    // Clear existing options except the first two (No Label, Create New)
    [taskSelect, detailSelect].forEach(select => {
        while (select.options.length > 2) {
            select.remove(2);
        }

        // Add label options
        labels.forEach(label => {
            const option = document.createElement('option');
            option.value = JSON.stringify(label);
            option.textContent = `${getColorEmoji(label.color)} ${label.name}`;
            select.add(option);
        });
    });
}

function getColorEmoji(color) {
    const emojiMap = {
        'red': '🔴',
        'orange': '🟠',
        'yellow': '🟡',
        'green': '🟢',
        'blue': '🔵',
        'purple': '🟣',
        'pink': '🌸',
        'gray': '⚪'
    };
    return emojiMap[color] || '';
}

async function createTask() {
    const description = document.getElementById('taskDescription').value.trim();
    const details = document.getElementById('taskDetails').value.trim();
    const stepsText = document.getElementById('taskSteps').value.trim();
    const dueDate = document.getElementById('taskDueDate').value;

    if (!description) {
        await showAlert('Please enter a task description');
        return;
    }

    const steps = stepsText
        .split('\n')
        .map(s => s.trim())
        .filter(s => s.length > 0);

    // Get label from select or create new
    let label = null;
    const labelSelect = document.getElementById('taskLabelSelect').value;

    if (labelSelect && labelSelect !== '__new__') {
        // Use existing label
        label = JSON.parse(labelSelect);
    } else if (labelSelect === '__new__') {
        // Create new label
        const labelName = document.getElementById('taskLabelName').value.trim();
        const labelColor = document.getElementById('taskLabelColor').value;

        if (labelName && labelColor) {
            label = {
                name: labelName,
                color: labelColor
            };
        }
    }

    const payload = {
        description,
        details: details || null,
        steps: steps.length > 0 ? steps : null,
        due_date: dueDate || null,
        label: label
    };

    try {
        const response = await fetch(`${API_BASE}/tasks`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const newTask = await response.json();
        tasks.push(newTask);

        // Reload labels to include any new ones
        await loadLabels();
        renderTasks();
        hideNewTaskDialog();

        // Clear form
        document.getElementById('taskDescription').value = '';
        document.getElementById('taskDetails').value = '';
        document.getElementById('taskSteps').value = '';
        document.getElementById('taskDueDate').value = '';
        document.getElementById('taskLabelSelect').value = '';
        document.getElementById('taskLabelName').value = '';
        document.getElementById('taskLabelColor').value = '';
        document.getElementById('taskNewLabelFields').style.display = 'none';
    } catch (error) {
        console.error('Failed to create task:', error);
        await showAlert('Failed to create task');
    }
}

async function updateTaskStatus(taskId, newStatus) {
    try {
        await fetch(`${API_BASE}/tasks/${taskId}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: newStatus })
        });

        const task = tasks.find(t => t.id === taskId);
        if (task) {
            task.status = newStatus;
            renderTasks();
        }
    } catch (error) {
        console.error('Failed to update task:', error);
    }
}

async function deleteTask(taskId) {
    const confirmed = await showConfirm('Are you sure you want to delete this task?');
    if (!confirmed) {
        return;
    }

    try {
        await fetch(`${API_BASE}/tasks/${taskId}`, {
            method: 'DELETE'
        });

        tasks = tasks.filter(t => t.id !== taskId);
        renderTasks();
    } catch (error) {
        console.error('Failed to delete task:', error);
    }
}

async function handleDeleteTask() {
    if (!currentTaskId) return;

    if (preferences.confirmDelete) {
        const confirmed = await showConfirm('Are you sure you want to delete this task? This action cannot be undone.');
        if (!confirmed) {
            return;
        }
    }

    try {
        await fetch(`${API_BASE}/tasks/${currentTaskId}`, {
            method: 'DELETE'
        });

        tasks = tasks.filter(t => t.id !== currentTaskId);
        renderTasks();
        hideDetailsDialog();
    } catch (error) {
        console.error('Failed to delete task:', error);
        await showAlert('Failed to delete task');
    }
}

async function saveTaskDetails() {
    if (!currentTaskId) return;

    const description = document.getElementById('detailDescription').value.trim();
    const details = document.getElementById('detailDetails').value.trim();
    const dueDate = document.getElementById('detailDueDate').value;

    // Get label from select or create new
    let label = null;
    const labelSelect = document.getElementById('detailLabelSelect').value;

    if (labelSelect && labelSelect !== '__new__') {
        // Use existing label
        label = JSON.parse(labelSelect);
    } else if (labelSelect === '__new__') {
        // Create new label
        const labelName = document.getElementById('detailLabelName').value.trim();
        const labelColor = document.getElementById('detailLabelColor').value;

        if (labelName && labelColor) {
            label = {
                name: labelName,
                color: labelColor
            };
        }
    }

    const payload = {
        description: description || undefined,
        details: details || undefined,
        due_date: dueDate || undefined,
        label: label || undefined
    };

    try {
        await fetch(`${API_BASE}/tasks/${currentTaskId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        // Reload labels to include any new ones
        await loadLabels();
        await loadTasks();
        hideDetailsDialog();
    } catch (error) {
        console.error('Failed to save task details:', error);
        await showAlert('Failed to save task details');
    }
}

async function addComment() {
    if (!currentTaskId) return;

    const commentText = document.getElementById('newComment').value.trim();
    if (!commentText) return;

    try {
        await fetch(`${API_BASE}/tasks/${currentTaskId}/comments`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: commentText })
        });

        document.getElementById('newComment').value = '';
        await loadTasks();
        const task = tasks.find(t => t.id === currentTaskId);
        if (task) {
            renderComments(task);
            updateCommentTabLabel(task);
        }
        switchTab('comments');
    } catch (error) {
        console.error('Failed to add comment:', error);
    }
}

async function toggleStep(stepIndex) {
    if (!currentTaskId) return;

    try {
        await fetch(`${API_BASE}/tasks/${currentTaskId}/toggle-step`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ step_index: stepIndex })
        });

        await loadTasks();
        showTaskDetails(currentTaskId);
        switchTab('steps');
    } catch (error) {
        console.error('Failed to toggle step:', error);
    }
}

async function addStep() {
    if (!currentTaskId) return;

    const input = document.getElementById('newStepInput');
    const stepText = input.value.trim();

    if (!stepText) return;

    const task = tasks.find(t => t.id === currentTaskId);
    if (!task) return;

    const newSteps = [...task.steps, { text: stepText, completed: false }];

    try {
        await fetch(`${API_BASE}/tasks/${currentTaskId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ steps: newSteps })
        });

        input.value = '';
        await loadTasks();
        showTaskDetails(currentTaskId);
        switchTab('steps');
    } catch (error) {
        console.error('Failed to add step:', error);
        await showAlert('Failed to add step');
    }
}

async function updateStepText(stepIndex, newText) {
    if (!currentTaskId) return;

    const task = tasks.find(t => t.id === currentTaskId);
    if (!task) return;

    const updatedSteps = task.steps.map((step, idx) =>
        idx === stepIndex ? { ...step, text: newText.trim() } : step
    );

    try {
        await fetch(`${API_BASE}/tasks/${currentTaskId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ steps: updatedSteps })
        });

        await loadTasks();
        const updatedTask = tasks.find(t => t.id === currentTaskId);
        if (updatedTask) {
            renderSteps(updatedTask);
        }
    } catch (error) {
        console.error('Failed to update step:', error);
    }
}

async function deleteStep(stepIndex) {
    if (!currentTaskId) return;

    if (preferences.confirmDelete) {
        const confirmed = await showConfirm('Delete this step?');
        if (!confirmed) return;
    }

    const task = tasks.find(t => t.id === currentTaskId);
    if (!task) return;

    const updatedSteps = task.steps.filter((_, idx) => idx !== stepIndex);

    try {
        await fetch(`${API_BASE}/tasks/${currentTaskId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ steps: updatedSteps })
        });

        await loadTasks();
        showTaskDetails(currentTaskId);
        switchTab('steps');
    } catch (error) {
        console.error('Failed to delete step:', error);
        await showAlert('Failed to delete step');
    }
}

// Rendering
function renderTasks() {
    const columns = {
        notstarted: document.getElementById('notstarted-column'),
        inprogress: document.getElementById('inprogress-column'),
        inreview: document.getElementById('inreview-column'),
        blocked: document.getElementById('blocked-column'),
        complete: document.getElementById('complete-column')
    };

    // Clear columns
    Object.values(columns).forEach(col => col.innerHTML = '');

    // Group tasks by status
    const grouped = {
        notstarted: [],
        inprogress: [],
        inreview: [],
        blocked: [],
        complete: []
    };

    tasks.forEach(task => {
        // Skip completed tasks if preference is set
        if (preferences.hideCompleted && task.status === 'complete') {
            return;
        }
        grouped[task.status].push(task);
    });

    // Render tasks in each column
    Object.entries(grouped).forEach(([status, statusTasks]) => {
        const column = columns[status];
        statusTasks.forEach(task => {
            column.appendChild(createTaskCard(task));
        });

        // Update counter
        const countElem = column.closest('.column').querySelector('.column-count');
        countElem.textContent = statusTasks.length;
    });
}

function createTaskCard(task) {
    const card = document.createElement('div');
    card.className = 'task-card';
    if (task.status === 'complete') {
        card.classList.add('completed');
    }
    card.draggable = true;
    card.dataset.taskId = task.id;

    // Header
    const header = document.createElement('div');
    header.className = 'task-card-header';

    const id = document.createElement('span');
    id.className = 'task-id';
    id.textContent = `#${task.id}`;

    const desc = document.createElement('span');
    desc.textContent = task.description;

    header.appendChild(id);
    header.appendChild(desc);

    // Label badge
    if (task.label) {
        const badge = document.createElement('span');
        badge.className = `label-badge label-${task.label.color}`;
        badge.textContent = task.label.name;
        header.appendChild(badge);
    }

    card.appendChild(header);

    // Steps
    if (task.steps && task.steps.length > 0) {
        const completedCount = task.steps.filter(s => s.completed).length;
        const steps = document.createElement('div');
        steps.className = 'task-steps';
        steps.textContent = `📋 ${completedCount}/${task.steps.length} steps`;
        card.appendChild(steps);
    }

    // Due date
    if (task.due_date) {
        const dueDate = new Date(task.due_date);
        const now = new Date();
        const isOverdue = dueDate < now && task.status !== 'complete';

        const dueLine = document.createElement('div');
        dueLine.style.fontSize = '9px';
        dueLine.style.marginTop = '4px';
        dueLine.style.color = isOverdue ? '#ff0000' : '#666';
        dueLine.textContent = `📅 Due: ${dueDate.toLocaleDateString()}`;
        card.appendChild(dueLine);
    }

    // Click to open details
    card.addEventListener('click', () => showTaskDetails(task.id));

    // Drag events
    card.addEventListener('dragstart', handleDragStart);
    card.addEventListener('dragend', handleDragEnd);

    return card;
}

// Task Details Dialog
function showTaskDetails(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    currentTaskId = taskId;

    // Populate general tab
    document.getElementById('detailDescription').value = task.description;
    document.getElementById('detailDetails').value = task.details || '';
    document.getElementById('detailDueDate').value = task.due_date || '';

    // Set label dropdown
    const detailLabelSelect = document.getElementById('detailLabelSelect');
    if (task.label) {
        // Find matching label in dropdown
        const labelValue = JSON.stringify(task.label);
        let found = false;
        for (let i = 0; i < detailLabelSelect.options.length; i++) {
            if (detailLabelSelect.options[i].value === labelValue) {
                detailLabelSelect.selectedIndex = i;
                found = true;
                break;
            }
        }
        if (!found) {
            detailLabelSelect.value = '';
        }
    } else {
        detailLabelSelect.value = '';
    }
    document.getElementById('detailNewLabelFields').style.display = 'none';

    // Populate steps tab
    renderSteps(task);

    // Populate comments tab
    renderComments(task);

    // Update comment count in tab
    updateCommentTabLabel(task);

    // Show dialog
    document.getElementById('taskDetailsDialog').style.display = 'block';
    document.getElementById('dialogOverlay').classList.add('active');
    switchTab('general');
}

function updateCommentTabLabel(task) {
    const commentsTab = document.querySelector('.tab-button[data-tab="comments"]');
    const count = task.comments ? task.comments.length : 0;
    commentsTab.textContent = count > 0 ? `Comments (${count})` : 'Comments';
}

function renderSteps(task) {
    const stepsList = document.getElementById('stepsList');
    stepsList.innerHTML = '';

    if (!task.steps || task.steps.length === 0) {
        stepsList.innerHTML = '<p style="color: #888;">No steps defined for this task.</p>';
        return;
    }

    task.steps.forEach((step, index) => {
        const item = document.createElement('div');
        item.className = 'step-item';
        if (step.completed) {
            item.classList.add('completed');
        }

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = step.completed;
        checkbox.addEventListener('change', () => toggleStep(index));

        const input = document.createElement('input');
        input.type = 'text';
        input.value = step.text;
        input.className = 'step-text-input';
        input.addEventListener('blur', () => updateStepText(index, input.value));
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                input.blur();
            }
        });

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = '×';
        deleteBtn.className = 'step-delete-btn';
        deleteBtn.addEventListener('click', () => deleteStep(index));

        item.appendChild(checkbox);
        item.appendChild(input);
        item.appendChild(deleteBtn);
        stepsList.appendChild(item);
    });
}

function renderComments(task) {
    const commentsList = document.getElementById('commentsList');
    commentsList.innerHTML = '';

    if (!task.comments || task.comments.length === 0) {
        commentsList.innerHTML = '<p style="color: #888;">No comments yet.</p>';
        return;
    }

    task.comments.forEach(comment => {
        const item = document.createElement('div');
        item.className = 'comment-item';

        const text = document.createElement('div');
        text.className = 'comment-text';
        text.innerHTML = linkifyText(comment.text);

        const meta = document.createElement('div');
        meta.className = 'comment-meta';
        meta.textContent = new Date(comment.created_at).toLocaleString();

        item.appendChild(text);
        item.appendChild(meta);
        commentsList.appendChild(item);
    });
}

function linkifyText(text) {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    return text.replace(urlRegex, '<a href="$1" target="_blank">$1</a>');
}

function switchTab(tabName) {
    // Update buttons
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.tab === tabName) {
            btn.classList.add('active');
        }
    });

    // Update content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.style.display = 'none';
    });
    document.getElementById(`tab-${tabName}`).style.display = 'block';
}

// Drag and Drop
function handleDragStart(e) {
    draggedTask = {
        id: parseInt(e.target.dataset.taskId),
        element: e.target
    };
    e.target.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
}

function handleDragEnd(e) {
    e.target.classList.remove('dragging');
    document.querySelectorAll('.column-body').forEach(col => {
        col.classList.remove('drag-over');
    });
}

function handleDragOver(e) {
    if (e.preventDefault) {
        e.preventDefault();
    }
    e.dataTransfer.dropEffect = 'move';
    e.currentTarget.classList.add('drag-over');
    return false;
}

function handleDragLeave(e) {
    e.currentTarget.classList.remove('drag-over');
}

function handleDrop(e) {
    if (e.stopPropagation) {
        e.stopPropagation();
    }
    e.preventDefault();

    const column = e.currentTarget;
    column.classList.remove('drag-over');

    if (draggedTask) {
        const newStatus = column.id.replace('-column', '');
        const task = tasks.find(t => t.id === draggedTask.id);

        if (task && task.status !== newStatus) {
            updateTaskStatus(draggedTask.id, newStatus);
        }
    }

    return false;
}

// Custom Dialogs
function showConfirm(message) {
    return new Promise((resolve) => {
        document.getElementById('confirmMessage').textContent = message;
        document.getElementById('confirmDialog').style.display = 'block';
        document.getElementById('dialogOverlay').classList.add('active');
        confirmCallback = resolve;
    });
}

function hideConfirmDialog() {
    document.getElementById('confirmDialog').style.display = 'none';
    document.getElementById('dialogOverlay').classList.remove('active');
}

function showAlert(message) {
    return new Promise((resolve) => {
        document.getElementById('alertMessage').textContent = message;
        document.getElementById('alertDialog').style.display = 'block';
        document.getElementById('dialogOverlay').classList.add('active');
        alertCallback = resolve;
    });
}

function hideAlertDialog() {
    document.getElementById('alertDialog').style.display = 'none';
    document.getElementById('dialogOverlay').classList.remove('active');
}

// Dialogs
function showNewTaskDialog() {
    document.getElementById('newTaskDialog').style.display = 'block';
    document.getElementById('dialogOverlay').classList.add('active');
    document.getElementById('taskDescription').focus();
}

function hideNewTaskDialog() {
    document.getElementById('newTaskDialog').style.display = 'none';
    document.getElementById('dialogOverlay').classList.remove('active');
}

function hideDetailsDialog() {
    document.getElementById('taskDetailsDialog').style.display = 'none';
    document.getElementById('dialogOverlay').classList.remove('active');
    currentTaskId = null;
}

// Preferences
function loadPreferences() {
    const saved = localStorage.getItem('taskManagerPreferences');
    if (saved) {
        preferences = { ...preferences, ...JSON.parse(saved) };
    }
}

function showPreferencesDialog() {
    document.getElementById('prefHideCompleted').checked = preferences.hideCompleted;
    document.getElementById('prefConfirmDelete').checked = preferences.confirmDelete;
    document.getElementById('prefAutoRefresh').value = preferences.autoRefresh.toString();

    document.getElementById('preferencesDialog').style.display = 'block';
    document.getElementById('dialogOverlay').classList.add('active');
}

function hidePreferencesDialog() {
    document.getElementById('preferencesDialog').style.display = 'none';
    document.getElementById('dialogOverlay').classList.remove('active');
}

function savePreferences() {
    preferences.hideCompleted = document.getElementById('prefHideCompleted').checked;
    preferences.confirmDelete = document.getElementById('prefConfirmDelete').checked;
    preferences.autoRefresh = parseInt(document.getElementById('prefAutoRefresh').value);

    localStorage.setItem('taskManagerPreferences', JSON.stringify(preferences));

    setupAutoRefresh();
    renderTasks();
    hidePreferencesDialog();
}

function setupAutoRefresh() {
    if (autoRefreshInterval) {
        clearInterval(autoRefreshInterval);
        autoRefreshInterval = null;
    }

    if (preferences.autoRefresh > 0) {
        autoRefreshInterval = setInterval(() => {
            loadTasks();
        }, preferences.autoRefresh * 1000);
    }
}

async function clearCompletedTasks() {
    const completedTasks = tasks.filter(t => t.status === 'complete');

    if (completedTasks.length === 0) {
        await showAlert('No completed tasks to clear.');
        return;
    }

    const confirmed = await showConfirm(`Delete all ${completedTasks.length} completed task(s)?`);
    if (!confirmed) return;

    try {
        for (const task of completedTasks) {
            await fetch(`${API_BASE}/tasks/${task.id}`, {
                method: 'DELETE'
            });
        }

        await loadTasks();
        await showAlert(`Cleared ${completedTasks.length} completed task(s).`);
        hidePreferencesDialog();
    } catch (error) {
        console.error('Failed to clear completed tasks:', error);
        await showAlert('Failed to clear completed tasks');
    }
}

